# Modern-Homepage-from-Figma-Design

Hi this is the source code of my tutorial on converting Figma design to a real website.<br/><br/>
Here is the link for the tutorial playlist: https://www.youtube.com/watch?v=IoufGbyblIY&list=PL0-e1OMq5RP4SspVeenLKzldN_IZhZKSy

Here is the demo: https://godsont.github.io/Modern-Homepage-from-Figma-Design/
